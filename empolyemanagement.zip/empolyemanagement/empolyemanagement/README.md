# Employee Management Service

A Gradle-based Spring Boot application for employee administration with a reusable common library module.

## Modules

- `common` - reusable business definitions used by the application
- `employee-service` - Spring Boot employee management application

## Features

- Create employee records
- View all employees
- Fetch a single employee by ID
- Update employee details
- Deactivate or delete employee records
- Validation errors for incomplete/invalid requests
- Swagger/OpenAPI documentation
- MySQL persistence

## Run

```bash
gradlew bootRun
```

## Swagger

Open: http://localhost:8080/swagger-ui.html

## Database

The application expects a MySQL database named `employee_management` running on localhost:3306.
