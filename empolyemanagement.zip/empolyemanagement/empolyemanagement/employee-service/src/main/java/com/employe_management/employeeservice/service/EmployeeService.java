package com.employe_management.employeeservice.service;

import com.employe_management.common.EmploymentStatus;
import com.employe_management.employeeservice.entity.Employee;
import com.employe_management.employeeservice.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found with id: " + id));
    }

    @Transactional
    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Transactional
    public Employee updateEmployee(Long id, Employee employeeDetails) {
        Employee employee = getEmployeeById(id);

        employee.setName(employeeDetails.getName());
        employee.setContactNumber(employeeDetails.getContactNumber());
        employee.setDesignation(employeeDetails.getDesignation());
        employee.setDepartment(employeeDetails.getDepartment());
        employee.setEmail(employeeDetails.getEmail());
        employee.setEmploymentStatus(employeeDetails.getEmploymentStatus());
        employee.setJoiningDate(employeeDetails.getJoiningDate());

        return employeeRepository.save(employee);
    }

    @Transactional
    public void deleteEmployee(Long id) {
        Employee employee = getEmployeeById(id);
        if (employee.getEmploymentStatus() == EmploymentStatus.ACTIVE) {
            employee.setEmploymentStatus(EmploymentStatus.INACTIVE);
            employeeRepository.save(employee);
            return;
        }
        employeeRepository.delete(employee);
    }
}
