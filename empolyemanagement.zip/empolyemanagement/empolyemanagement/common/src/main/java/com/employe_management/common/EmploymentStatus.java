package com.employe_management.common;

public enum EmploymentStatus {
    ACTIVE,
    INACTIVE,
    TERMINATED,
    ON_LEAVE
}
